package yaksha;

public class StudentInformation {
	private String information[];

	public StudentInformation(String[] information) {
		super();
		this.information = information;
	}

	public String[] getInformation() {
		return information;
	}

	public void setInformation(String[] information) {
		this.information = information;
	}

}
