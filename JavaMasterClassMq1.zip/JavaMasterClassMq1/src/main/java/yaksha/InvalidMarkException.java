package yaksha;

public class InvalidMarkException extends Exception {
	private static final long serialVersionUID = 1L;

	public InvalidMarkException(String s) {
		super(s);
	}
}