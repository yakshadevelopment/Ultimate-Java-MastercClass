package yaksha;

public class NumberList {
	private int number[];

	public int[] getNumber() {
		return number;
	}

	public void setNumber(int[] number) {
		this.number = number;
	}

	public NumberList(int[] number) {
		super();
		this.number = number;
	}
}