package yaksha;

import java.util.*;

public class MainClass {

	public static int checkSumOfOddEvenDigits(int number) {
		int sum = 0, result = 0;
		int number1 = number;
		while (number != 0) {
			int remainder = number % 10;
			sum = sum + remainder;
			number = number / 10;
		}
		if (sum % 2 != 0) {
			number = number1;
			sum = 0;
			while (number != 0) {
				int remainder = number % 10;
				if (remainder % 2 != 0) {
					sum = sum + remainder;
				}
				number = number / 10;
			}

			if (sum % 2 != 0) {
				result = 0;
			}
		} else if (sum % 2 == 0) {
			number = number1;
			sum = 0;
			while (number != 0) {
				int remainder = number % 10;
				if (remainder % 2 == 0) {
					sum = sum + remainder;
				}
				number = number / 10;
			}
			if (sum % 2 == 0) {
				result = 1;
			}
		}
		return result;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter a number");
		int number1 = scanner.nextInt();
		Number number = new Number(number1);
		if (checkSumOfOddEvenDigits(number.getNumber()) == 0)
			System.out.println("Sum of odd digits is odd");
		else
			System.out.println("Sum of even digits is even");
		scanner.close();
	}
}
